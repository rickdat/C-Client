using System;
using System.Net;
using System.IO;

namespace AstraRestExample
{
    class Program
    {

        public string ReadJsonCreateTable()
        {
            //Json creates a table named demo_table
            using (StreamReader r = new StreamReader("CreateTable.json"))
            {
                string CreateTable = r.ReadToEnd();
                return CreateTable;
            }
        }

        public string ReadJsonAddRow()
        {
            //Json Inserts data into demo_table
            using (StreamReader r = new StreamReader("AddRow.json"))
            {
                string CreateTable = r.ReadToEnd();
                return CreateTable;
            }
        }

        public void PostRequest(string url, string token, string JsonBody)
        {
            var httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "POST";
            httpWebRequest.Headers.Add("X-Cassandra-Token", token);

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                streamWriter.Write(JsonBody);
            }

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                Console.WriteLine(result);
            }
        }


        static void Main(string[] args)
        {
            // The code provided will perform basic operations on Astra
            //Replace the values below by your actual environment values
            // Press Ctrl+F5 (or go to Debug > Start Without Debugging) to run your app.
            var JsonBody = new Program();
            string CreateTableJson = JsonBody.ReadJsonCreateTable();
            string AddRowJson = JsonBody.ReadJsonAddRow();
            string urlCreateTable = "https://{{db}}-{{region}}.apps.astra.datastax.com/api/rest/v1/keyspaces/demo_keyspace/tables";
            string urlAddRow = "https://{{db}}-{{region}}.apps.astra.datastax.com/api/rest/v1/keyspaces/demo_keyspace/tables/demo_table/rows";
            string token = "AstraCS:ZZRhYTTpHnBBFcydqzDWtumZ:e6d618c05db9a4864b6f87669b405c526769c00a2a7a036a0027d8566040552b";

            var RequestObject = new Program();
            RequestObject.PostRequest(urlCreateTable, token, CreateTableJson);
            RequestObject.PostRequest(urlAddRow, token, AddRowJson);

        }
    }
}
